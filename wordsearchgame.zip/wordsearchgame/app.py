import random
import string
import streamlit as st

# === PREDEFINED THEMES ===
theme_words = {
    "fruit": ["apple", "mango", "banana", "grape"],
    "color": ["blue", "green", "red", "pink"],
    "space": ["moon", "star", "sun", "comet"]
}

# === FUNCTION TO CREATE GRID ===
def create_grid(words, size=10):
    grid = [['' for _ in range(size)] for _ in range(size)]
    word_positions = {}
    directions = [(0, 1), (1, 0), (1, 1)]  # Right, Down, Diagonal

    for word in words:
        placed = False
        while not placed:
            dir_x, dir_y = random.choice(directions)
            x = random.randint(0, size - 1)
            y = random.randint(0, size - 1)
            if x + dir_x * len(word) > size or y + dir_y * len(word) > size:
                continue
            fits = True
            for i in range(len(word)):
                nx = x + dir_x * i
                ny = y + dir_y * i
                if grid[nx][ny] not in ('', word[i]):
                    fits = False
                    break
            if fits:
                word_positions[word] = [(x + dir_x * i, y + dir_y * i) for i in range(len(word))]
                for i in range(len(word)):
                    grid[x + dir_x * i][y + dir_y * i] = word[i]
                placed = True

    for i in range(size):
        for j in range(size):
            if grid[i][j] == '':
                grid[i][j] = random.choice(string.ascii_lowercase)
    return grid, word_positions

# === STREAMLIT PAGE SETUP ===
st.set_page_config(page_title=" Word Search Game", layout="centered")
st.title("Word Search Game")

# === THEME SELECTION ===
chosen_theme = st.selectbox(" Choose a theme:", list(theme_words.keys()))

# === INIT STATE FOR SELECTED THEME ===
if "current_theme" not in st.session_state or st.session_state.current_theme != chosen_theme:
    st.session_state.current_theme = chosen_theme
    st.session_state.words = theme_words[chosen_theme]
    st.session_state.grid, st.session_state.positions = create_grid(st.session_state.words)
    st.session_state.found_words = set()

# === USER INPUT ===
guess = st.text_input(" Enter a word you found:").lower()

if guess:
    if guess in st.session_state.words and guess not in st.session_state.found_words:
        st.session_state.found_words.add(guess)
        st.success(f" Found: {guess}")
    elif guess in st.session_state.found_words:
        st.warning(" Already found!")
    else:
        st.error(" Not in the list!")

# === DISPLAY GRID ===
grid_html = '<div style="display: grid; grid-template-columns: repeat(10, 40px); gap: 5px;">'
for i in range(10):
    for j in range(10):
        char = st.session_state.grid[i][j].upper()
        color = "white"
        for word in st.session_state.found_words:
            if (i, j) in st.session_state.positions[word]:
                color = "lightgreen"
                break
        grid_html += f'<div style="width: 40px; height: 40px; background-color: {color}; display: flex; align-items: center; justify-content: center; border: 1px solid #999; font-weight: bold;">{char}</div>'
grid_html += '</div>'
st.markdown(grid_html, unsafe_allow_html=True)

st.write(" Words Found:", list(st.session_state.found_words))
